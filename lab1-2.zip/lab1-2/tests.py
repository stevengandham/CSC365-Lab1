""" ALLEN ZHAI, WEI LIN, STEVEN GANDHAM """
import unittest
from functions import *
import schoolsearch
import student
import io
import sys


class Test(unittest.TestCase):

    def testR4(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R4(students, "HAVIR"), [["HAVIR","BOBBIE","2","108",
                                                  "HAMER","GAVIN"]])

    def testR5(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R5(students, "HAVIR"), [["HAVIR","BOBBIE","0"]])

    def testR6(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R6(students, "HAMER"), [["LIBRANDI", "TODD"],
                                                 ["HAVIR", "BOBBIE"],
                                                 ["SARAO", "DIEDRA"],
                                                 ["VANCOTT", "MIKE"],
                                                 ["WICINSKY", "TERESE"],
                                                 ["KOZOLA", "BUSTER"],
                                                 ["MULLINGS", "LEIGHANN"],
                                                 ["BUSSMANN", "BILLY"],
                                                 ["BERBES", "DICK"],
                                                 ["MULGREW", "RANDELL"],
                                                 ["TOWLEY", "LANE"]])
        self.assertEqual(R6(students, "ZHAI"), [])

    def testR7(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R7(students, "1"), [["SAELEE", "DANILO"],
                                             ["GARTH", "JOHN"]])
        self.assertEqual(R7(students, "99"), [])

    def testR8(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R8(students, "51"), [["WOOLERY", "NOLAN", "2", "104"],
                                              ["STERBACK", "PETER", "6", "111"],
                                              ["LIBRANDI", "TODD", "2", "108"],
                                              ["RAPOSE", "ALONZO", "4", "105"],
                                              ["COVINGTON", "TOMAS", "3", "107"],
                                              ["MULLINGS", "LEIGHANN", "2", "108"],
                                              ["DURAND", "CARLEE", "4", "101"],
                                              ["FRIEDSTROM", "REED", "6", "106"]])
        self.assertEqual(R8(students, "1000"), [])

    def testR9(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R9(students, "3 H"),
                        [["SWEDLUND","SHARRI","3.24","FAFARD","ROCIO","55"]])
        self.assertEqual(R9(students, "3 Low"),
                        [["CIGANEK","MANIE","2.79","FAFARD","ROCIO", "53"]])
        self.assertEqual(R9(students, "99 Low"), [])
        self.assertEqual(R9(students, "99 High"), [])

    def testR10(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R10(students, "3"), [["3,3.05"]])
        self.assertEqual(R10(students, "99"), [])

    def testR11(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(R11(students), [['Grade 0', '0'],
                                        ['Grade 1', '2'],
                                        ['Grade 2', '13'],
                                        ['Grade 3', '9'],
                                        ['Grade 4', '15'],
                                        ['Grade 5', '0'],
                                        ['Grade 6', '21']])


    def ErrorHandling(self):
        students = student.parseStudents("test.txt", "teachers.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("list.txt", "test.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("test.txt", "test1.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students), True)

    def testALL(self):
        students = student.parseStudents("test.txt", "teachers.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("list.txt", "test.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("test.txt", "test1.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students),False)
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(schoolsearch.checkLoadFile(students), True)
        self.assertEqual(R4(students, "HAVIR"), [["HAVIR","BOBBIE","2","108",
                                                  "HAMER","GAVIN"]])
        self.assertEqual(R5(students, "HAVIR"), [["HAVIR","BOBBIE","0"]])
        self.assertEqual(R6(students, "HAMER"), [["LIBRANDI", "TODD"],
                                                 ["HAVIR", "BOBBIE"],
                                                 ["SARAO", "DIEDRA"],
                                                 ["VANCOTT", "MIKE"],
                                                 ["WICINSKY", "TERESE"],
                                                 ["KOZOLA", "BUSTER"],
                                                 ["MULLINGS", "LEIGHANN"],
                                                 ["BUSSMANN", "BILLY"],
                                                 ["BERBES", "DICK"],
                                                 ["MULGREW", "RANDELL"],
                                                 ["TOWLEY", "LANE"]])
        self.assertEqual(R6(students, "ZHAI"), [])
        self.assertEqual(R7(students, "1"), [["SAELEE", "DANILO"],
                                             ["GARTH", "JOHN"]])
        self.assertEqual(R7(students, "99"), [])
        self.assertEqual(R8(students, "51"), [["WOOLERY", "NOLAN", "2", "104"],
                                              ["STERBACK", "PETER", "6", "111"],
                                              ["LIBRANDI", "TODD", "2", "108"],
                                              ["RAPOSE", "ALONZO", "4", "105"],
                                              ["COVINGTON", "TOMAS", "3", "107"],
                                              ["MULLINGS", "LEIGHANN", "2", "108"],
                                              ["DURAND", "CARLEE", "4", "101"],
                                              ["FRIEDSTROM", "REED", "6", "106"]])
        self.assertEqual(R8(students, "1000"), [])
        self.assertEqual(R9(students, "3 H"),
                        [["SWEDLUND","SHARRI","3.24","FAFARD","ROCIO","55"]])
        self.assertEqual(R9(students, "3 Low"),
                        [["CIGANEK","MANIE","2.79","FAFARD","ROCIO", "53"]])
        self.assertEqual(R9(students, "99 Low"), [])
        self.assertEqual(R9(students, "99 High"), [])
        self.assertEqual(R10(students, "3"), [["3,3.05"]])
        self.assertEqual(R10(students, "99"), [])
        self.assertEqual(R11(students), [['Grade 0', '0'],
                                        ['Grade 1', '2'],
                                        ['Grade 2', '13'],
                                        ['Grade 3', '9'],
                                        ['Grade 4', '15'],
                                        ['Grade 5', '0'],
                                        ['Grade 6', '21']])
    def testNR1(self):
        self.maxDiff = None;
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(NR1(students, "105"), [['CORKER', 'CARTER'],
                                                 ['IMMERMAN', 'DEVIN'],
                                                 ['RAPOSE', 'ALONZO'],
                                                 ['OGAS', 'ERVIN'],
                                                 ['MASSART', 'ELDON'],
                                                 ['BEX', 'TAMESHA']])
    def testNR3(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(NR3(students, '2'), [["STEIB", "GALE"], ["HAMER", "GAVIN"]])

    def testNR4(self):
        students = student.parseStudents("list.txt","teachers.txt")
        self.assertEqual(NR4(students), [["Room 101", "1 student(s)"],
                                         ["Room 102", "5 student(s)"],
                                         ["Room 103", "2 student(s)"],
                                         ["Room 104", "2 student(s)"],
                                         ["Room 105", "6 student(s)"],
                                         ["Room 106", "2 student(s)"],
                                         ["Room 107", "7 student(s)"],
                                         ["Room 108", "11 student(s)"],
                                         ["Room 109", "5 student(s)"],
                                         ["Room 110", "2 student(s)"],
                                         ["Room 111", "9 student(s)"],
                                         ["Room 112", "8 student(s)"]]) 

    def testNR5(self):
        students = student.parseStudents("list.txt","teachers.txt")
        g,t,b = NR5(students)
        self.assertEqual(g,[['Grade 1','3.0'],['Grade 2','2.95'],
                            ['Grade 3','3.05'],['Grade 4','2.95'],
                            ['Grade 6','2.98']])
        self.assertEqual(t,[['ALPERT','3.17'],['BODZIONY','3.09'],
                            ['CHIONCHIO','2.98'],['COOL','2.91'],
                            ['FAFARD','3.01'],['FALKER','3.0'],
                            ['GAMBREL','2.96'],['HAMER','2.95'],
                            ['HANTZ','2.91'],['KERBS','2.98'],
                            ['NISTENDIRK','2.96'],['STEIB','2.9']])
        self.assertEqual(b,[['Route 0','2.95'],['Route 51','3.02'],
                            ['Route 52','2.88'], ['Route 53','3.06'],
                            ['Route 54','2.94'],['Route 55','3.04'],
                            ['Route 56','2.92']])

if __name__ == "__main__":
    unittest.main()
