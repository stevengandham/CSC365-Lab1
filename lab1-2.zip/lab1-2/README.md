# CSC365-Lab1: Allen Zhai, Steven Gandham, Wei Lin
CSC 365 Databases Lab 1

To run program, run the command:
python3 schoolSearch.py

To run tests, run the command:
python3 tests.py
         or
python3 schoolsearch.py < tests.txt

Usage For New Required Commands:
	NR1: C[lass] <number> S[tudents]
	NR2  C[lass] <number> T[eachers]
	NR3: G[rade] <number> T[eachers]
	NR4: E[nrollment]
	NR5: D[ata]
