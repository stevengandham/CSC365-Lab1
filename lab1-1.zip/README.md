# CSC365-Lab1: Allen Zhai, Steven Gandham, Wei Lin
CSC 365 Databases Lab 1

To run program, run the command:
python3 schoolSearch.py

To run tests, run the command:
python3 tests.py
